var a = document.getElementById("admin");
var b = document.getElementById("user");

function admin() {
    a.style.left = "-5px";
    b.style.left = "-1000px";
}

function user() {
    b.style.left = "5px";
    a.style.left = "1000px";
}